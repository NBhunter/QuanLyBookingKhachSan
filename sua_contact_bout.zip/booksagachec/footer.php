<hr class="mb-0">
<footer align='center'>Bản quyền &copy; của nô lệ đồng tiền DH20TH1.</footer>