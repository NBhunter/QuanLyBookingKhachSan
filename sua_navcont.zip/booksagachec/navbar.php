<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">

<script src="https://kit.fontawesome.com/d899a74ef7.js" crossorigin="anonymous"></script>
</head>
<body><!-- Top navigation -->

		<div class="topnav">
			<div class="row">
				<div class="col-lg-4">
				  <!-- Centered link -->
				  <div class="topnav-centered">
					<a href="index.php" class="active">Home</a>
				  </div>
				</div>

		  <!-- Left-aligned links (default) -->
			<div class="col-lg-4">
				<a href="#news">News</a>
				<a href="#contact">Contact</a>
			</div>
			  <!-- Right-aligned links -->
			<div class="col-lg-4">
			  <div class="topnav-right">
				<a href="#search">Search</a>
				<a href="#about">About</a>
			  </div>
			</div>
		</div>
	</div>
</body>
</html>